import React, { createContext, useContext } from 'react'
const Ctx = createContext(null)
export function Tabs({ value, onValueChange, children, className }){
  return <Ctx.Provider value={{ value, onValueChange }}><div className={className}>{children}</div></Ctx.Provider>
}
export function TabsList({ children, className }){ return <div className={`rounded-xl border p-1 grid grid-cols-3 gap-1 ${className||''}`}>{children}</div> }
export function TabsTrigger({ value, children, className }){
  const ctx = useContext(Ctx)
  const active = ctx?.value === value
  return <button onClick={()=> ctx?.onValueChange?.(value)} className={`rounded-lg px-3 py-2 text-sm border ${active? 'bg-gray-100 border-gray-300' : 'border-transparent hover:bg-gray-50'} ${className||''}`}>{children}</button>
}
export function TabsContent({ value, children }){
  const ctx = useContext(Ctx)
  if (ctx?.value !== value) return null
  return <div className="mt-3">{children}</div>
}