import React from 'react'
export function Switch({ checked, onCheckedChange }){
  return <label className="inline-flex items-center gap-2 cursor-pointer">
    <input type="checkbox" checked={checked} onChange={e=> onCheckedChange?.(e.target.checked)} />
  </label>
}