import React from 'react'
export function Dialog({ children }){ return <>{children}</> }
export function DialogTrigger({ asChild, children }){ return <>{children}</> }
export function DialogContent({ children }){ return <div className="p-3">{children}</div> }
export function DialogHeader({ children }){ return <div className="mb-2">{children}</div> }
export function DialogTitle({ children }){ return <div className="text-lg font-semibold">{children}</div> }
export function DialogDescription({ children }){ return <div className="text-sm text-gray-600">{children}</div> }
export function DialogFooter({ children }){ return <div className="mt-2">{children}</div> }