import React from 'react'
export function Select({ value, onValueChange, children }){ return <div>{React.Children.map(children, (c)=> React.cloneElement(c, { value, onValueChange }))}</div> }
export function SelectTrigger({ children }){ return <div className="h-9 rounded-md border px-3 flex items-center">{children}</div> }
export function SelectValue(){ return <span className="text-sm text-gray-600">выберите…</span> }
export function SelectContent({ children, value, onValueChange }){
  return <div className="mt-2 grid gap-1">{React.Children.map(children, (c)=> React.cloneElement(c, { onValueChange }))}</div>
}
export function SelectItem({ value, children, onValueChange }){
  return <button className="text-left rounded-md border px-3 py-2 hover:bg-gray-50" onClick={()=> onValueChange?.(value)}>{children}</button>
}