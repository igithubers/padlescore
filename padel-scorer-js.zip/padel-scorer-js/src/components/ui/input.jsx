import React from 'react'
export function Input(props){
  return <input {...props} className={`h-9 w-full rounded-md border border-gray-300 px-3 ${props.className||''}`} />
}